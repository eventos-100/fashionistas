export const langs = [
  { value: 'en', label: 'English', countryCode: 'GB' },
  { value: 'fr', label: 'French', countryCode: 'FR' },
  { value: 'de', label: 'German', countryCode: 'DE' },
];
