import { createClasses } from 'src/theme/create-classes';

// ----------------------------------------------------------------------

export const svgColorClasses = {
  root: createClasses('svg__color__root'),
};
